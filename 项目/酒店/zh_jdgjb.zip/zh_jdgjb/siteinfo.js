var siteInfo = {
    'title': '',
    'uniacid': '2',
    'acid': '2',
    'multiid': '0',
    'version': '1.0',
    'siteroot': 'https://jiudian.fsdxdk.com/app/index.php',
    'design_method': '3',
    'redirect_module': '',
    'template': ''
}
module.exports = siteInfo