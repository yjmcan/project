var siteInfo = {
  'title': '',
  'uniacid': '71',
  'acid': '71',
  'multiid': '0',
  'version': '1.0',
  'siteroot': 'https://hl.zhycms.com/app/index.php',
  'design_method': '3',
  'redirect_module': '',
  'template': '',
  'version': '1.0'
}
module.exports = siteInfo