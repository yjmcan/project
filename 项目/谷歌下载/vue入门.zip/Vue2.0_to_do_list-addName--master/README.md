# Vue2.0_to_do_list addName

> 根据[慕课网Vue入门视频](http://www.imooc.com/learn/694 "vue.js入门基础") ，加上了自己的详细注释，希望能帮到你，有问题请留言。
> 只需要关注src文件下的App.vue即可，所有功能均在此文件内实现，
> 另外通过localstorage.js实现了本地储存，具体请搜索html5的localstorage相关知识，感谢视频作者和慕课网的无私分享。
## 怎么使用 

``` 命令
# 安装依赖包
npm install

# 运行项目（浏览器自行打开页面，修改代码自动刷新）
npm run dev

```


