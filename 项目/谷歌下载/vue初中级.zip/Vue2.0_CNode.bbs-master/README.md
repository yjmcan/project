# CNode

> 根据CNode社区提供的API使用Vue2.x + Webpack + axios + Vue-router 实现了社区基础功能， 内含代码注释，希望能帮到你~

## Build Setup

``` bash
# 安装依赖
npm install

# 运行项目 localhost:8080
npm run dev

# 项目打包
npm run build

```


