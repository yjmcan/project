var siteInfo = {
  'title': '',
  'uniacid': '24',
  'acid': '24',
  'multiid': '0',
  'version': '1.0',
  'siteroot': 'https://zhycms.com/app/index.php',
  'design_method': '3',
  'redirect_module': '',
  'template': '',
  'version': '1.0'
}
module.exports = siteInfo