var siteInfo = {
  'title': '',
  'uniacid': '6',
  'acid': '6',
  'multiid': '0',
  'version': '1.0',
  'siteroot': 'https://zfb.zhycms.com/app/index.php',
  'design_method': '3',
  'redirect_module': '',
  'template': ''
}
module.exports = siteInfo